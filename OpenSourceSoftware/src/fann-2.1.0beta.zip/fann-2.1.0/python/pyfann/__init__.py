#
# Fast Artificial Neural Network library for Python
#
import libfann
__all__ = [
    'libfann'
]
